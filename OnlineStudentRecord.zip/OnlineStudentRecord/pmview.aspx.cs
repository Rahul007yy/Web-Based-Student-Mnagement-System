﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class pmview : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string stude = Session["username"].ToString();
        DataAccess da = new DataAccess();
        da.DBDataAdapter("select student_id,Student_Name,Department,Semester,subject1,total1,subject2,total2,subject3,total3,subject4,total4,subject5,total5,subject6,total6,percentage from marks where Student_Name='" + Session["username"].ToString() + "'", gvques);
    }
}
