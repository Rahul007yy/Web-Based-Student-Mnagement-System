﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class sviewatten : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string stude = Session["username"].ToString();

        DataAccess da = new DataAccess();
        da.DBDataAdapter("select * from attendance where studentname='" + Session["username"].ToString() + "'", gvques);
    }
}