﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Drawing.Imaging;
using System.IO;
using System.Net;
using System.Net.Mail;



public partial class newuser : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("server=.;database=accademic;integrated security=true;");
    SqlCommand cmd;

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    public void mail(string emailid, string msge)
    {
        string email = emailid;
        string pwd;

        Random rp = new Random();
        MailMessage msg = new MailMessage();
        msg.To.Add(email);
        msg.From = new MailAddress("hasidata@gmail.com");
        msg.Subject = "Greetings from Digitized Student Attendance Application System..";
        pwd = rp.Next(11111, 99999).ToString();
        msg.Body = msge;
       


        SmtpClient cli = new SmtpClient("smtp.gmail.com", 587);
        cli.EnableSsl = true;
        NetworkCredential nc = new NetworkCredential("hasidata@gmail.com", "hasi12345");
        cli.Credentials = nc;
        try
        {
          cli.Send(msg);
        }
        catch (Exception ex)
        { }
    


    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        string gender = "";


        con.Open();
        if (rbmale.Checked == true)
        {
            gender = "Male";
        }
        else
        {
            gender = "Female";
        }

        string s = "insert into student values('" + txtName.Text + "','" + txtuid.Text + "','" + txtPassword.Text + "','" + txtPassword0.Text + "','" + txtdob.Text + "','" + gender + "','" + txtEmail.Text + "','" + txtph.Text + "','" + txtaddress.Text + "','" + txtdep.Text + "','" + ddlmode.SelectedItem.ToString() + "')";
        cmd = new SqlCommand(s, con);
        try
        {
            cmd.ExecuteNonQuery();
            performance();
            Response.Write("<script language='javascript'>alert('Student details inserted successfully')</script>");
        }
        catch (Exception ex)
        { 
        
        }
        
        con.Close();
       
      adddata();
       
        txtaddress.Text = "";
        txtdep.Text = "";
        txtEmail.Text = "";
        txtPassword.Text = "";
        txtPassword0.Text = "";
        txtuid.Text = "";
       
    }
    SqlConnection connection;

    public void adddata()
    {
        con.Close();
        con.Open();
        string s = "insert into login values('" + txtPassword.Text + "','" + txtPassword0.Text + "','Parent')";
        cmd = new SqlCommand(s, con);
        cmd.ExecuteNonQuery();
        con.Close();
    
    }
    private void performance()
    {
        con.Close();
        con.Open();
        SqlCommand cmd = new SqlCommand("insert into performance values('" + txtuid.Text + "','" + ddlmode.Text + "','Null','Null','Null','Null','Null','Null')", con);
        cmd.ExecuteNonQuery();
    }
   
}
