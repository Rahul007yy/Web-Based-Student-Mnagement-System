﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
public partial class stotalatten : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("server=.;database=accademic;integrated security=true;");
    SqlCommand cmd;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack != true)
        {
            sid();
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        con.Close();
        con.Open();
        SqlCommand cmd = new SqlCommand("insert into totattendance values('" + DropDownList1.Text + "','" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + DropDownList2.Text + "','" + TextBox5.Text + "','" + TextBox6.Text + "','" + TextBox7.Text + "','"+TextBox8.Text +"')", con);
        cmd.ExecuteNonQuery();
        Response.Write("<script>alert('Student Attendance Added Successfully')</script>");
        update();
        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox3.Text = "";
        TextBox8.Text = "";
        TextBox5.Text = "";
        TextBox6.Text = "";
        TextBox7.Text = "";
        DropDownList1.Text = "";
        DropDownList2.Text = "";
        con.Close();
    }
    private void sid()
    {
        con.Close();
        con.Open();
        SqlCommand cmd = new SqlCommand("select regno from attendance", con);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            DropDownList1.Items.Add(dr[0].ToString());
        }
        dr.Close();
        con.Close();
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlCommand cmd1 = new SqlCommand("select studentname,department,semester from attendance where regno='" + DropDownList1.Text + "'", con);
        con.Open();
        SqlDataReader dr = cmd1.ExecuteReader();
        while (dr.Read())
        {
            TextBox1.Text = (dr[0].ToString());
            TextBox2.Text = (dr[1].ToString());
            TextBox3.Text = (dr[2].ToString());
        }
        con.Close();
    }
    protected void TextBox6_TextChanged(object sender, EventArgs e)
    {
        TextBox7.Text =((Convert.ToInt32 (TextBox5.Text )-((Convert.ToInt32 (TextBox6.Text ))))).ToString ();
        TextBox8.Text =((Convert.ToInt32 (TextBox6.Text ))).ToString ();

    }
    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {
      
    }
    private void update()
    {
        try
        {
            con.Close();
            con.Open();
            SqlCommand cmd = new SqlCommand("update performance set registernumber='" + DropDownList1.Text + "',department='" + TextBox2.Text + "',attendancemonth='" + DropDownList2.Text + "',attendancepercentage='" + TextBox8.Text + "' where registernumber='" + DropDownList1.Text + "'", con);
            cmd.ExecuteNonQuery();
            con.Close();
        }
        catch (Exception ex)
        {

        }
    }
}