﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.IO;
using System.Net;
using System.Net.Mail;
using System.Data.SqlClient;


public partial class smark : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("server=.;database=accademic;integrated security=true;");
    SqlCommand cmd;
    protected void Page_Load(object sender, EventArgs e)
    {
       
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (TextBox1.Text == "" && TextBox2.Text == "" && TextBox3.Text == "" && TextBox4.Text == "" && TextBox5.Text == "" && TextBox6.Text == "" && TextBox7.Text == "" && TextBox8.Text == "" && TextBox9.Text == "" && TextBox10.Text == "" && TextBox11.Text == "" && TextBox12.Text == "" && TextBox13.Text == "" && TextBox14.Text == "" && DropDownList1.Text == "")
        {
            Response.Write("<script>alert('Must Fill All Values')</script>");
        }
        else
        {
            con.Close();
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into dairy values('" + TextBox1.Text + "','"+DropDownList1.Text +"','"+DropDownList2.Text  +"','"+DropDownList3.Text +"','" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "','" + TextBox5.Text + "','" + TextBox6.Text + "','" + TextBox7.Text + "','" + TextBox8.Text + "','" + TextBox9.Text + "','" + TextBox10.Text + "','" + TextBox11.Text + "','" + TextBox12.Text + "','" + TextBox13.Text + "','" + TextBox14.Text + "','" + TextBox15.Text + "')", con);
            cmd.ExecuteNonQuery();
            update();
            Response.Write("<script>alert('Test Mark Details Entered Successfully')</script>");
            con.Close();
        }
      
    }
   
    public void mail(string emailid, string msge)
    {
        string email = emailid;
        string pwd;

        Random rp = new Random();
        MailMessage msg = new MailMessage();
        msg.To.Add(email);
        msg.From = new MailAddress("hasidata@gmail.com");
        msg.Subject = "Notification from E-Diary..";
        pwd = rp.Next(11111, 99999).ToString();
        msg.Body = msge;
        SmtpClient cli = new SmtpClient("smtp.gmail.com", 587);
        cli.EnableSsl = true;
        NetworkCredential nc = new NetworkCredential("hasidata@gmail.com", "hasi12345");
        cli.Credentials = nc;
        try
        {
            cli.Send(msg);
        }
        catch (Exception ex)
        { }
      


    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
       
    }
    protected void RadioButton1_CheckedChanged(object sender, EventArgs e)
    {
       
    }
    protected void RadioButton2_CheckedChanged(object sender, EventArgs e)
    {
       
    }
    protected void RadioButton3_CheckedChanged(object sender, EventArgs e)
    {
       
    }
    private void sid()
    {
        
    }

    protected void ddlmode_SelectedIndexChanged(object sender, EventArgs e)
    {
        
    }
    protected void TextBox13_TextChanged(object sender, EventArgs e)
    {
        TextBox14.Text =((Convert.ToInt32 (TextBox8.Text )) + ((Convert.ToInt32 (TextBox9.Text )) + ((Convert.ToInt32 (TextBox10.Text )) + ((Convert.ToInt32 (TextBox11.Text )) + ((Convert.ToInt32 (TextBox12.Text )) + ((Convert.ToInt32 (TextBox13.Text )))))))).ToString ();
        TextBox15.Text =((Convert.ToInt32 (TextBox14.Text )/6)).ToString (); 
    }
    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {
        con.Close();
        con.Open();
        SqlCommand cmd = new SqlCommand("select student_id from student where Sclass='" + DropDownList2.Text  + "'", con);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            DropDownList3.Items.Add(dr[0].ToString());
        }
    }

    private void update()
    {
        try
        {
            con.Close();
            con.Open();
            SqlCommand cmd = new SqlCommand("update performance set testaverage='" + TextBox15.Text + "' where registernumber='" + DropDownList3.Text + "'", con);
            cmd.ExecuteNonQuery();
            con.Close();
        }
        catch (Exception ex)
        {

        }
    }
}
