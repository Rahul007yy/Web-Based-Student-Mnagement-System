﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
public partial class Attendance : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("server=.;database=accademic;integrated security=true;");
    SqlConnection con1 = new SqlConnection("server=.;database=accademic;integrated security=true;");
    SqlCommand cmd;
    SqlCommand cmd1;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack!= true)
        {
            sid();
        }
        TextBox4.Text = System.DateTime.Now.ToShortDateString();
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        con.Close();
        con.Open();
        SqlCommand cmd = new SqlCommand("insert into attendance values('"+DropDownList1.Text +"','" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "','"+DropDownList2.Text +"','" + TextBox5.Text + "','" + TextBox6.Text + "','" + TextBox7.Text + "','"+TextBox8.Text +"')", con);
        cmd.ExecuteNonQuery();
        Response.Write("<script>alert('Student Attendance Added Successfully')</script>");
        con.Close();
        con1.Close();
        con1.Open();
        SqlCommand cmd1 = new SqlCommand("select email_id from student where student_id='" + DropDownList1.Text + "'", con1);
        SqlDataReader dr1 = cmd1.ExecuteReader();
        if (dr1.Read())
        {
            TextBox8.Text = (dr1[0].ToString()); 
            email();
        }
        clear();
        con1.Close();
        
    }
    private void sid()
    {
        con.Close();
        con.Open();
        SqlCommand cmd = new SqlCommand("select student_id from student", con);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            DropDownList1.Items.Add(dr[0].ToString());
        }
        dr.Close();
        con.Close();
    }


    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlCommand cmd1 = new SqlCommand("select student_name,Sclass from student where student_id='" + DropDownList1.Text + "'", con);
        con.Open();
        SqlDataReader dr = cmd1.ExecuteReader();
        while (dr.Read())
        {
            TextBox1.Text = (dr[0].ToString());
            TextBox2.Text = (dr[1].ToString());
        }
        con.Close();
    }
    private void email()
    {
        try
        {
            con.Close();
            con.Open();
            System.Net.Mail.MailMessage mail = new System.Net.Mail.MailMessage();
            System.Net.NetworkCredential cred = new System.Net.NetworkCredential("hasidata@gmail.com", "ranji@276");
            mail.To.Add(TextBox8.Text);
            mail.Subject = "Student Attendance Mail";
            mail.From = new System.Net.Mail.MailAddress("hasidata@gmail.com");
            mail.IsBodyHtml = true; // Aceptamos HTML
            mail.Body = "Dear Parent Your Son/Daughter:'" + TextBox1.Text + "',Department: '" + TextBox2.Text + "',Attendance Date:'" + TextBox4.Text + "',Present Hours:'" + TextBox6.Text + "',Absent hours:'" + TextBox7.Text + "'";
            System.Net.Mail.SmtpClient smtp = new System.Net.Mail.SmtpClient("smtp.gmail.com");
            smtp.UseDefaultCredentials = false;
            smtp.EnableSsl = true;
            smtp.Credentials = cred; //asignamos la credencial
            smtp.Send(mail);
            Response.Write("<script>alert(' Attendance Alert mail send to Parent Successfully)</script>");
            con.Close();
        }
        catch (Exception)
        {

        }
    }
    private void clear()
    {
        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox3.Text = "";
        TextBox4.Text = "";
        TextBox5.Text = "";
        TextBox6.Text = "";
        TextBox7.Text = "";
        DropDownList1.Text = "";
        DropDownList2.Text = "";
        con.Close();
    }
    protected void TextBox6_TextChanged(object sender, EventArgs e)
    {
        TextBox7.Text = ((Convert.ToInt32(TextBox5.Text) - ((Convert.ToInt32(TextBox6.Text))))).ToString();
    }
}