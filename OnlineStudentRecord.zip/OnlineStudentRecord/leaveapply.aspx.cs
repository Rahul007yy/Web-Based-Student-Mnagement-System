﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Drawing.Imaging;
using System.IO;
using System.Net;
using System.Net.Mail;



public partial class leaveapply : System.Web.UI.Page
{
    int count;
    SqlConnection con = new SqlConnection("server=.;database=accademic;integrated security=true;");
    SqlCommand cmd;

    protected void Page_Load(object sender, EventArgs e)
    {
        lid();
        txtuid.Text = System.DateTime.Now.ToShortDateString();
    }
    public void mail(string emailid, string msge)
    {
        

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        string gender = "";


        con.Open();
        if (rbmale.Checked == true)
        {
            gender = "Normal Leave";
        }
        else
        {
            gender = "Medical Leave";
        }

        string s = "insert into leaveapply values('" + TextBox1.Text  + "','" + txtName.Text + "','" + txtuid.Text + "','" + txtPassword.Text + "','" + txtPassword0.Text + "','" + txtdob.Text + "','" + gender + "')";
        cmd = new SqlCommand(s, con);
        try
        {
            cmd.ExecuteNonQuery();
            Response.Write("<script language='javascript'>alert('Leave Application Request sent successfully')</script>");
        }
        catch (Exception ex)
        { }
       
       
        
      
       
    }
    SqlConnection connection;
        private void sms(string msg, string phone)
    {
       
    }

   

    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {
      
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
      

    }
    private void lid()
    {
        //con.Open();
        //SqlCommand cmd1 = new SqlCommand("select max(lno) from leaveapply", con);
        //TextBox1.Text = Convert.ToString(Convert.ToUInt32(cmd1.ExecuteScalar()) + 1);
        //con.Close();
        con.Close();
        con.Open();
        SqlCommand cmd = new SqlCommand("select count (*) from leaveapply", con);
        cmd.ExecuteNonQuery();
        count = Convert.ToInt16(cmd.ExecuteScalar()) + 1;
        TextBox1.Text = count.ToString();
        con.Close();
    }
}
