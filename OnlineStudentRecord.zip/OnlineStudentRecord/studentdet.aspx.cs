﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
public partial class studentdet : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("server=.;database=accademic;integrated security=true;");
    SqlCommand cmd;
    protected void Page_Load(object sender, EventArgs e)
    {

        con.Open();
        string se = "select * from student";
        cmd = new SqlCommand(se, con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds, "a");
        gvques.DataSource = ds;
        gvques.DataBind();
        con.Close();
    }
}
