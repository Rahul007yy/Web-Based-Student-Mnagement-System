﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class staffreports : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        SqlDataAdapter da = new SqlDataAdapter("select distinct * from feedback where staff_id='" + Session["sname"].ToString() + "'", con);
        DataSet ds = new DataSet();
        da.Fill(ds);

        GridView1.DataSource = ds;
        GridView1.DataBind();
       
    }
    SqlConnection con = new SqlConnection("server=.;integrated security=true;database=accademic");
    
    protected void gdImage_SelectedIndexChanged(object sender, EventArgs e)
    {
       
    }
  
}
