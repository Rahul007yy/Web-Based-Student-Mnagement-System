﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;


public partial class exam : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        loadcm();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Session["Domain"] = DropDownList1.Text;
        Response.Redirect("TakeTest1.aspx");
    }
    public void loadcm()
    {
        SqlConnection con = new SqlConnection("server=.;database=accademic;integrated security=true;");

        con.Open();
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "select distinct staff_id from staff where department='" + Session["depname"].ToString() + "'";
        //string s="select * from login where id='" + TextBox1.Text + "' and Password='" + TextBox2.Text + " '";
        cmd.Connection = con;
        SqlDataReader dr;
        dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            try
            {
                TextBox1.Text =dr[0].ToString().ToString();

                DropDownList1.Items.Add(dr[0].ToString().ToString());
            }
            catch (Exception ex)
            {
                //TextBox1.Text = "1";

            }
        }
       
        con.Close();
    }

    public void loadcm1()
    {
        SqlConnection con = new SqlConnection("server=.;database=accademic;integrated security=true;");

        con.Open();
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "select staff_name  from staff where staff_id='" + DropDownList1.Text + "'";
        //string s="select * from login where id='" + TextBox1.Text + "' and Password='" + TextBox2.Text + " '";
        cmd.Connection = con;
        SqlDataReader dr;
        dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            try
            {
                TextBox1.Text = dr[0].ToString().ToString();

               // DropDownList1.Items.Add(dr[0].ToString().ToString());
            }
            catch (Exception ex)
            {
                //TextBox1.Text = "1";

            }
        }

        con.Close();
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        loadcm1();
    }
}
