﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.IO;
using System.Net;
using System.Net.Mail;


public partial class sdiary : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("server=.;database=accademic;integrated security=true;");
    SqlCommand cmd;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack != true)
        {
            sid();
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        grade();
        con.Open();
        string s = "insert into marks values('" + DropDownList1.Text + "','" + TextBox1.Text + "','" + ddlmode.Text + "','" + DropDownList2.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "','" + TextBox5.Text + "','" + TextBox6.Text + "','" + TextBox7.Text + "','" + TextBox8.Text + "','" + TextBox9.Text + "','" + TextBox10.Text + "','" + TextBox11.Text + "','" + TextBox12.Text + "','" + TextBox13.Text + "','" + TextBox14.Text + "','" + TextBox15.Text + "','" + TextBox16.Text + "','" + TextBox17.Text + "','" + TextBox18.Text + "','" + TextBox19.Text + "','" + TextBox20.Text + "','" + TextBox21.Text + "','" + TextBox22.Text + "','" + TextBox23.Text + "','" + TextBox24.Text + "','" + TextBox25.Text + "','"+TextBox28.Text +"','" + TextBox26.Text + "','" + TextBox27.Text + "')";
        cmd = new SqlCommand(s, con);
        try
        {
            cmd.ExecuteNonQuery();
            update();
            Response.Write("<script language='javascript'>alert('Student Mark inserted successfully')</script>");
        }
        catch (Exception ex)
        { }
      
        con.Close();
      
    }
    private void sms(string msg, string phone)
    {
        try
        {
           
        }
        catch (Exception ex)
        {
        }
    }
    public void mail(string emailid, string msge)
    {
        string email = emailid;
        string pwd;

        Random rp = new Random();
        MailMessage msg = new MailMessage();
        msg.To.Add(email);
        msg.From = new MailAddress("hasidata@gmail.com");
        msg.Subject = "Notification from Accademic Evaluation System..";
        pwd = rp.Next(11111, 99999).ToString();
        msg.Body = msge;



        SmtpClient cli = new SmtpClient("smtp.gmail.com", 587);
        cli.EnableSsl = true;
        NetworkCredential nc = new NetworkCredential("hasidata@gmail.com", "ranji@276");
        cli.Credentials = nc;
        try
        {
            cli.Send(msg);
        }
        catch (Exception ex)
        { }
      


    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        DataAccess da = new DataAccess();
        SqlDataReader dr = da.DBReaderOpen("select student_name from student where student_id='" + DropDownList1.Text + "'");
        while (dr.Read())
        {
            TextBox1.Text = dr[0].ToString();
            // DropDownList2.Items.Add(dr[0].ToString());
        }
    }
    private void sid()
    {
        DataAccess da = new DataAccess();
        SqlDataReader dr = da.DBReaderOpen("select student_id from student");
        while (dr.Read())
        {
            DropDownList1.Items.Add(dr[0].ToString());
            //DropDownList2.Items.Add(dr[0].ToString());
        }
    }
    protected void TextBox9_TextChanged(object sender, EventArgs e)
    {
        TextBox10.Text =((Convert.ToInt32 (TextBox8.Text )+((Convert.ToInt32 (TextBox9.Text ))))).ToString ();
    }
    protected void TextBox12_TextChanged(object sender, EventArgs e)
    {
        TextBox13.Text = ((Convert.ToInt32(TextBox11.Text) + ((Convert.ToInt32(TextBox12.Text))))).ToString();
    }
    protected void TextBox15_TextChanged(object sender, EventArgs e)
    {
        TextBox16.Text = ((Convert.ToInt32(TextBox14.Text) + ((Convert.ToInt32(TextBox15.Text))))).ToString();
    }
    protected void TextBox18_TextChanged(object sender, EventArgs e)
    {
        TextBox19.Text = ((Convert.ToInt32(TextBox17.Text) + ((Convert.ToInt32(TextBox18.Text))))).ToString();
    }
    protected void TextBox21_TextChanged(object sender, EventArgs e)
    {
        TextBox22.Text = ((Convert.ToInt32(TextBox20.Text) + ((Convert.ToInt32(TextBox21.Text))))).ToString();
    }
    protected void TextBox24_TextChanged(object sender, EventArgs e)
    {
        TextBox25.Text = ((Convert.ToInt32(TextBox23.Text) + ((Convert.ToInt32(TextBox24.Text))))).ToString();
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        TextBox28.Text = ((Convert.ToInt32(TextBox10.Text) + ((Convert.ToInt32(TextBox13.Text)) + ((Convert.ToInt32(TextBox16.Text)) + ((Convert.ToInt32(TextBox19.Text)) + ((Convert.ToInt32(TextBox22.Text)) + ((Convert.ToInt32(TextBox25.Text))))))))).ToString();
        TextBox26.Text = ((Convert.ToInt32(TextBox28.Text) / 6 )).ToString();
    }
    private void grade()
    {
        int mark = 95;
   
        if ((Convert.ToInt32 (TextBox26.Text ))>= 85 )
        {
            TextBox27.Text ="Grade A";
        }
        else if ((Convert.ToInt32(TextBox26.Text)) >= 70)
        {
            TextBox27.Text = "Grade B";
        }
        else if ((Convert.ToInt32(TextBox26.Text)) <= 70)
        {
            TextBox27.Text = "Grade C";
        }

    }
    private void update()
    {
        try
        {
            con.Close();
            con.Open();
            SqlCommand cmd = new SqlCommand("update performance set semester='" + DropDownList2.Text + "',percentage='" + TextBox26.Text + "',grade='" + TextBox27.Text + "' where registernumber='" + DropDownList1.Text + "'", con);
            cmd.ExecuteNonQuery();
            con.Close();
        }
        catch (Exception ex)
        {

        }
    }
   
}
