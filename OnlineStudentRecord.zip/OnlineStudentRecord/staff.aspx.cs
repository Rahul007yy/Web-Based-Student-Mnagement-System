﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Drawing.Imaging;
using System.IO;
using System.Net;
using System.Net.Mail;



public partial class staff : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("server=.;database=accademic;integrated security=true;");
    SqlCommand cmd;

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    public void mail(string emailid, string msge)
    {
        string email = emailid;
        string pwd;

        Random rp = new Random();
        MailMessage msg = new MailMessage();
        msg.To.Add(email);
        msg.From = new MailAddress("jothicse89@gmail.com");
        msg.Subject = "Greetings from Faculty Feedback applicaiton..";
        pwd = rp.Next(11111, 99999).ToString();
        msg.Body = msge;
       


        SmtpClient cli = new SmtpClient("smtp.gmail.com", 587);
        cli.EnableSsl = true;
        NetworkCredential nc = new NetworkCredential("jothicse89@gmail.com", "jothi@12345");
        cli.Credentials = nc;
        try
        {
          cli.Send(msg);
        }
        catch (Exception ex)
        { }
     //   Label1.Text = ("QRcode sent to user through Mail!!!!");


    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        string gender = "";


        con.Open();
        if (rbmale.Checked == true)
        {
            gender = "Male";
        }
        else
        {
            gender = "Female";
        }
        string s = "insert into staff values('" + txtName.Text + "','" + txtuid.Text + "','" + txtPassword.Text + "','" + txtPassword0.Text + "','" + txtdob.Text + "','" + gender + "','" + txtEmail.Text + "','" + txtph.Text + "','" + txtaddress.Text + "','" + txtdep.Text + "','" + ddlmode.SelectedItem.ToString() + "','" + ddesign.Text + "','" + txtdoj.Text + "','" + txtexperience.Text + "')";
        cmd = new SqlCommand(s, con);
        cmd.ExecuteNonQuery();
        Response.Write("<script language='javascript'>alert('Staff details inserted successfully')</script>");
        con.Close();
        string mssg= "Dear: "+ txtName.Text +", Your details are registered in faculty feedback applicaiton.. Now you can login into the website using the following details. Userid : "+ txtPassword.Text + " and Password : "+ txtPassword0.Text ;

        mail(txtEmail.Text, mssg);
      adddata();

                 
        txtaddress.Text = "";
        txtdep.Text = "";
        txtEmail.Text = "";
        txtPassword.Text = "";
        txtPassword0.Text = "";
        txtuid.Text = "";
       
    }
    SqlConnection connection;

    public void adddata()
    {
        con.Close();
        con.Open();
        string s = "insert into login values('" + txtPassword.Text + "','" + txtPassword0.Text + "','Staff')";
        cmd = new SqlCommand(s, con);
        cmd.ExecuteNonQuery();
        con.Close();
        //connection = new SqlConnection("server=.;integrated security=true;database=accademic;");

        //try
        //{

        //    FileUpload img = (FileUpload)imgUpload;
        //    Byte[] imgByte = null;
        //    if (img.HasFile && img.PostedFile != null)
        //    {
        //        HttpPostedFile File = imgUpload.PostedFile;

        //        imgByte = new Byte[File.ContentLength];

        //        File.InputStream.Read(imgByte, 0, File.ContentLength);

        //    }

        //    string myMap = MapPath("~/").ToLower();
        //    string ImageName = img.PostedFile.FileName;

        //    string ImageSaveURL = myMap + "stuimages/" + ImageName;

        //    img.PostedFile.SaveAs(ImageSaveURL);
        //  //  rgb rr = new rgb();
        //  //  Bitmap foo = Bitmap.FromFile(ImageSaveURL) as Bitmap;
        //    int[] rgbArray = new int[100];
           

        //    connection.Open();
        //    string sql = "INSERT INTO studimg VALUES(@student_id,@imgtype,@imgpath)";


        //    SqlCommand cmd1 = new SqlCommand(sql, connection);
        //    cmd1.Parameters.AddWithValue("@student_id", txtUsername.Text.Trim());
        //    cmd1.Parameters.AddWithValue("@imgtype", imgByte);
        //    cmd1.Parameters.AddWithValue("@imgpath ", ImageSaveURL );



        //    cmd1.ExecuteNonQuery();
       


        //}

        //catch (Exception enn)
        //{
        //    Response.Write("<script language='javascript' type='text/javascript'>alert('Inserted');</script>");
        //}
        //finally
        //{
        //    connection.Close();
        //    //TextBox2.Text = "";

        //}
    
    }
   
}
