﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Net;
using System.Net.Mail;
using System.IO;
using System.Text.RegularExpressions;
public partial class announcement : System.Web.UI.Page
{
    int count;
    SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=accademic;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {
        
        DataAccess da = new DataAccess();
        da.DBDataAdapter("select * from addevent", GridView1);
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
       
    }
  
}
