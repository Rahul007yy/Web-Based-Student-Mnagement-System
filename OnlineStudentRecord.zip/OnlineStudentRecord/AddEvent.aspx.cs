﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Net;
using System.Net.Mail;
using System.IO;
using System.Text.RegularExpressions;
public partial class AddEvent : System.Web.UI.Page
{
    int count;
    SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=accademic;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {
        TextBox1.Text = System.DateTime.Now.ToShortDateString();
        rid();
        if (IsPostBack != true)
        {
            sname();
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (TextBox2.Text == "" && TextBox3.Text == "" && TextBox4.Text == "" && TextBox5.Text == "" && TextBox6.Text == "" && TextBox7.Text == "" && DropDownList1.Text == "")
        {
            Response.Write("<script>alert('Must Fill All Values')</script>");
        }
        else
        {
            con.Close();
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into addevent values('" + TextBox1.Text + "','" + TextBox2.Text + "','" + DropDownList1.Text + "','" + TextBox3.Text + "','"+DropDownList2.Text +"','" + TextBox4.Text + "','" + TextBox5.Text + "','" + DropDownList3.Text + "','" + TextBox6.Text + "','" + TextBox7.Text + "')", con);
            cmd.ExecuteNonQuery();
            Response.Write("<script>alert('New Event Details Added Successfully')</script>");
            TextBox3.Text = "";
            TextBox4.Text = "";
            TextBox5.Text = "";
            TextBox6.Text = "";
            TextBox7.Text = "";
            DropDownList1.Text = "";
            DropDownList2.Text = "";
            DropDownList3.Text = "";
            con.Close();
        }
    }
    private void rid()
    {

        con.Close();
        con.Open();
        SqlCommand cmd = new SqlCommand("select count (*) from addevent", con);
        cmd.ExecuteNonQuery();
        count = Convert.ToInt16(cmd.ExecuteScalar()) + 1;
        TextBox2.Text = count.ToString();
        con.Close();
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        TextBox3.Text = "";
        TextBox4.Text = "";
        TextBox5.Text = "";
        TextBox6.Text = "";
        TextBox7.Text = "";
        DropDownList1.Text = "";
        DropDownList2.Text = "";
        DropDownList3.Text = "";

    }
    private void sname()
    {
        con.Close();
        con.Open();
        SqlCommand cmd = new SqlCommand("select staff_name from staff ", con);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {

            DropDownList3.Items.Add(dr[0].ToString());
        }
        con.Close();
    }
    protected void DropDownList3_SelectedIndexChanged(object sender, EventArgs e)
    {
        con.Close();
        con.Open();
        SqlCommand cmd = new SqlCommand("select phone from staff where staff_name='"+DropDownList3.Text +"'", con);
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
        {

            TextBox6.Text =(dr[0].ToString());
        }
        con.Close();
    }
}