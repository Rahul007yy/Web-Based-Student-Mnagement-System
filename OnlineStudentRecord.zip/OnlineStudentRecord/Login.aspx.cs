﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.IO;
using System.Net;
using System.Net.Mail;
using System.Data.SqlClient;

public partial class Login : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("server=.;database=accademic;integrated security=true;");
    SqlCommand cmd;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    private void sms(string msg, string phone)
    {
        try
        {
            string strUrl = "http://api.mVaayoo.com/mvaayooapi/MessageCompose?user=selva.tamil84@gmail.com:smsdump&senderID=TEST SMS&receipientno=" + phone + "&msgtxt= " + msg + "&state=4";
            WebRequest request = HttpWebRequest.Create(strUrl);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            Stream s = (Stream)response.GetResponseStream();
            StreamReader readStream = new StreamReader(s);
            string dataString = readStream.ReadToEnd();
            response.Close();
            s.Close();
            readStream.Close();
        }
        catch (Exception ex)
        {
        }
    }
    public void mail(string emailid, string msge)
    {
        string email = emailid;
        string pwd;

        Random rp = new Random();
        MailMessage msg = new MailMessage();
        msg.To.Add(email);
        msg.From = new MailAddress("hasidata@gmail.com");
        msg.Subject = "Notification from E-Diary..";
        pwd = rp.Next(11111, 99999).ToString();
        msg.Body = msge;



        SmtpClient cli = new SmtpClient("smtp.gmail.com", 587);
        cli.EnableSsl = true;
        NetworkCredential nc = new NetworkCredential("hasidata@gmail.com", "hasi12345");
        cli.Credentials = nc;
        try
        {
            cli.Send(msg);
        }
        catch (Exception ex)
        { }
        //   Label1.Text = ("QRcode sent to user through Mail!!!!");


    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        
       
            if (txtPassword.Text == "Admin" && txtUsername.Text == "Admin" &&  DropDownList1.Text=="Admin")
            {
                Session["username"] = txtUsername.Text;
                Server.Transfer("Adminhome.aspx");
                // Response.TransmitFile("Adminhome.aspx");
            }

            //else if (txtPassword.Text == "Principal" && txtUsername.Text == "Principal" && DropDownList1.Text == "Principal")
            //{
            //    Session["username"] = txtUsername.Text;
            //    Server.Transfer("Adminhome.aspx");
            //    // Response.TransmitFile("Adminhome.aspx");
            //}
        else
        {

            con.Open();
            string sel = "select * from login where userid='" + txtUsername.Text + "' and password='" + txtPassword.Text + "'";
            cmd = new SqlCommand(sel, con);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                
                if (dr[2].ToString() == "Staff")
                {
                    Session["username"] = txtUsername.Text;
                    Server.Transfer("staffhome.aspx");

                }
                else if (dr[2].ToString() == "Parent")
                {
                    //send OTP
                    DataAccess da = new DataAccess();
                  //  da.DBCmdOpen("insert into diary values ('" + DropDownList1.Text + "','" + TextBox1.Text + "','" + ddlmode.Text + "','" + DropDownList2.Text + "','" + TextBox4.Text + "','" + DateTime.Now.ToShortDateString() + "','" + Label1.Text + "')");
                    SqlDataReader drr = da.DBReaderOpen("select user_id,password from student where user_id='" + txtUsername.Text + "' and password='"+txtPassword.Text +"'");
                    if (drr.Read())
                    {
                        Session["username"] = txtUsername.Text;
                        Server.Transfer("student.aspx");
                    }
                    Panel1.Visible = true;
                   
                }
            }
            else
            {
                Response.Write("<script language='javascript'>alert('invalid username,password')</script>");
            }
            con.Close();

        }
        
       
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (TextBox1.Text == Label5.Text)
        {
            Server.Transfer("student.aspx");
        }
    }
    protected void Button1_Click1(object sender, EventArgs e)
    {
        if (TextBox1.Text == Label5.Text)
        {
            Server.Transfer("student.aspx");
        }
    }
}
