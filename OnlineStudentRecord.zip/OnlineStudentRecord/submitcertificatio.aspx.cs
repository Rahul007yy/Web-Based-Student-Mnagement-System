﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class submitcertificatio : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        SqlDataAdapter da = new SqlDataAdapter("select distinct * from attendance", con);
        DataSet ds = new DataSet();
        da.Fill(ds);
        gdImage.DataSource = ds;
        gdImage.DataBind();
    }
    SqlConnection con = new SqlConnection("server=.;integrated security=true;database=accademic");

    protected void gdImage_SelectedIndexChanged(object sender, EventArgs e)
    {
       
    }
    protected void subm_Click(object sender, EventArgs e)
    {
        GridViewRow grdrow = (GridViewRow)((LinkButton)sender).NamingContainer;
        string prono = grdrow.Cells[0].Text;
        string sponsorname = grdrow.Cells[5].Text;
        string filename = grdrow.Cells[1].Text;
        string productsize = grdrow.Cells[4].Text;
        string productname = grdrow.Cells[3].Text;
       // int rows1 = downloadlog(prono, filename, sponsorname, Session["username"].ToString(), productsize, DateTime.Now.ToString());
        //if (rows1 > 0)
        //{
            //folder(productname);
            Response.Write("<script>alert('record submitted..')</script>");

        //}


    }
}
