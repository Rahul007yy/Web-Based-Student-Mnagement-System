﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
public partial class staffdet : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("server=.;database=accademic;integrated security=true;");
    SqlCommand cmd;
    protected void Page_Load(object sender, EventArgs e)
    {
        string stude = Session["username"].ToString();
       // string[] studet = stude.Split('-');


        con.Open();
        string se = "select * from staff where staff_name='" + stude.ToString() + "'";
        cmd = new SqlCommand(se, con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds, "a");
        gvques.DataSource = ds;
        gvques.DataBind();
        con.Close();
    }
}
