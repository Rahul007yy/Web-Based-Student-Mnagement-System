﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class student : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("server=.;database=accademic;integrated security=true;");
    SqlCommand cmd;
    protected void Page_Load(object sender, EventArgs e)
    {
        Label1.Text = Session["username"].ToString();

        //con.Open();
        //SqlCommand cmd = new SqlCommand();
        //cmd.CommandText = "select department from student where user_id='" + Label1.Text + "'";
        ////string s="select * from login where id='" + TextBox1.Text + "' and Password='" + TextBox2.Text + " '";
        //cmd.Connection = con;
        //SqlDataReader dr;
        //dr = cmd.ExecuteReader();
        //if (dr.Read())
        //{
        //    try
        //    {
        //        Session["depname"] = dr[0].ToString();
              
        //    }
        //    catch (Exception ex)
        //    {
               

        //    }
        //}
        //else
        //{
           
        //}
        //con.Close();
    }
  
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
       
    }
}
